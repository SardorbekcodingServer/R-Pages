import { Link } from "react-router-dom";
import { useState } from "react";
import "./index.css";
import Img from '../../../../src/assets/img/Image.png';

function Register() {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleConfirmPasswordChange = (e) => {
    setConfirmPassword(e.target.value);

    if (password !== e.target.value) {
      setError("Parollar mos emas ❌");
    } else {
      setError("");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!error && password && confirmPassword) {
      alert("Ro'yxatdan muvaffaqiyatli o'tdingiz! ✅");
    }
  };

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const toggleShowConfirmPassword = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  return (
    <div className="auth-container">
      <div className="auth-left">
        <h2>Welcome to <span className="brand">OrgaFarm</span></h2>
        <h1>Register</h1>

        <form className="auth-form" onSubmit={handleSubmit}>
          <input type="email" placeholder="Email" required />

          <div className="password-wrapper">
            <input 
              type={showPassword ? "text" : "password"} 
              placeholder="Password" 
              value={password}
              onChange={handlePasswordChange}
              required
            />
            <span className="eye-icon" onClick={toggleShowPassword}>
              {showPassword ? "🍏" : "🍎"}
            </span>
          </div>

          <div className="password-wrapper">
            <input 
              type={showConfirmPassword ? "text" : "password"} 
              placeholder="Confirm Password" 
              value={confirmPassword}
              onChange={handleConfirmPasswordChange}
              required
            />
            <span className="eye-icon" onClick={toggleShowConfirmPassword}>
              {showConfirmPassword ? "🍏" : "🍎"}
            </span>
          </div>

          {error && <p className="error-message">{error}</p>}

          <button type="submit" disabled={!!error}>Register</button>
        </form>

        <p className="bottom-text">
          Already have an account? <Link to="/">Login</Link>
        </p>
      </div>

      <div className="auth-right">
       
      </div>
    </div>
  );
}

export default Register;
