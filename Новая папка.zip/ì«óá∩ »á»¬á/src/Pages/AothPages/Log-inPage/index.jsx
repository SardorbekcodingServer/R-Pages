import { Link } from "react-router-dom";
import "./index.css";
import Img from '../../../../src/assets/img/Image.png';

function Login() {
  return (
    <div className="auth-container">
      <div className="auth-left">
        <h2>Welcome back to <span className="brand">OrgaFarm</span></h2>
        <h1>Login</h1>

        <form className="auth-form">
          <input type="email" placeholder="Email" />
          <div className="password-wrapper">
            <input type="password" placeholder="Password" />
            
          </div>
          <div className="options">
            <label><input type="checkbox" /> Remember me</label>
            <a href="#">Forget Password?</a>
          </div>
          <button type="submit">Login</button>
        </form>

        <p className="bottom-text">
          Don’t have an account? <Link to="/register">Get Started</Link>
        </p>
      </div>

      <div className="auth-right">
        
      </div>
    </div>
  );
}

export default Login;   